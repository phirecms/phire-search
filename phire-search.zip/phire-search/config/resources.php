<?php

return [
    'searches' => [
        'index'
    ]
];