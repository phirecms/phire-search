<?php

return [
    '/search[/]' => [
        'controller' => 'Phire\Search\Controller\IndexController',
        'action'     => 'search'
    ]
];
